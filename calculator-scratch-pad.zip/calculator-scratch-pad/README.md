# Calculator scratch pad

A Pen created on CodePen.

Original URL: [https://codepen.io/xthan/pen/vEKZZJW](https://codepen.io/xthan/pen/vEKZZJW).

